<?php
/**
 * Created by PhpStorm.
 * User: Riccardo De Leo
 */
$entry_point_registry['PrivacyPreferencesEntryPoint'] = [
    'file' => 'modules/UP_GDPR_4_PP/PrivacyPreferencesEntryPoint.php',
    'auth' => false,
];