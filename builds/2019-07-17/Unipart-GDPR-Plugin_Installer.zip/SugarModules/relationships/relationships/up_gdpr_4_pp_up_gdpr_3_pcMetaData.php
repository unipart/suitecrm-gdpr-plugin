<?php
// created: 2019-07-16 13:38:59
$dictionary["up_gdpr_4_pp_up_gdpr_3_pc"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'up_gdpr_4_pp_up_gdpr_3_pc' => 
    array (
      'lhs_module' => 'UP_GDPR_4_PP',
      'lhs_table' => 'up_gdpr_4_pp',
      'lhs_key' => 'id',
      'rhs_module' => 'UP_GDPR_3_PC',
      'rhs_table' => 'up_gdpr_3_pc',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'up_gdpr_4_pp_up_gdpr_3_pc_c',
      'join_key_lhs' => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_4_pp_ida',
      'join_key_rhs' => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_3_pc_idb',
    ),
  ),
  'table' => 'up_gdpr_4_pp_up_gdpr_3_pc_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_4_pp_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_3_pc_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'up_gdpr_4_pp_up_gdpr_3_pcspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'up_gdpr_4_pp_up_gdpr_3_pc_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_4_pp_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'up_gdpr_4_pp_up_gdpr_3_pc_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_3_pc_idb',
      ),
    ),
  ),
);