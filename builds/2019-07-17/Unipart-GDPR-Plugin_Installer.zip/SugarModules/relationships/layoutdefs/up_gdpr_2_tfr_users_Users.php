<?php
 // created: 2019-07-16 13:39:00
$layout_defs["Users"]["subpanel_setup"]['up_gdpr_2_tfr_users'] = array (
  'order' => 100,
  'module' => 'UP_GDPR_2_TFR',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_UP_GDPR_2_TFR_TITLE',
  'get_subpanel_data' => 'up_gdpr_2_tfr_users',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
