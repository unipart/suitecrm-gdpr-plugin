<?php
 // created: 2019-07-16 13:38:59
$layout_defs["UP_GDPR_4_PP"]["subpanel_setup"]['up_gdpr_4_pp_up_gdpr_3_pc'] = array (
  'order' => 100,
  'module' => 'UP_GDPR_3_PC',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_UP_GDPR_4_PP_UP_GDPR_3_PC_FROM_UP_GDPR_3_PC_TITLE',
  'get_subpanel_data' => 'up_gdpr_4_pp_up_gdpr_3_pc',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
