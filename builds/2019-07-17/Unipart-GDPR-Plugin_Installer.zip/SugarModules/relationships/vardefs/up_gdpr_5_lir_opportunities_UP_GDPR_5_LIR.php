<?php
// created: 2019-07-16 13:39:00
$dictionary["UP_GDPR_5_LIR"]["fields"]["up_gdpr_5_lir_opportunities"] = array (
  'name' => 'up_gdpr_5_lir_opportunities',
  'type' => 'link',
  'relationship' => 'up_gdpr_5_lir_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_UP_GDPR_5_LIR_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'up_gdpr_5_lir_opportunitiesopportunities_idb',
);
$dictionary["UP_GDPR_5_LIR"]["fields"]["up_gdpr_5_lir_opportunities_name"] = array (
  'name' => 'up_gdpr_5_lir_opportunities_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_5_LIR_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_5_lir_opportunitiesopportunities_idb',
  'link' => 'up_gdpr_5_lir_opportunities',
  'table' => 'opportunities',
  'module' => 'Opportunities',
  'rname' => 'name',
);
$dictionary["UP_GDPR_5_LIR"]["fields"]["up_gdpr_5_lir_opportunitiesopportunities_idb"] = array (
  'name' => 'up_gdpr_5_lir_opportunitiesopportunities_idb',
  'type' => 'link',
  'relationship' => 'up_gdpr_5_lir_opportunities',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_5_LIR_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
);
