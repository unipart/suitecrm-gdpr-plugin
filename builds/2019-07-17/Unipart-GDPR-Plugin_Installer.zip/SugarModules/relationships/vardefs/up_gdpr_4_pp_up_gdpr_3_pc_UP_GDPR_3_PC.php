<?php
// created: 2019-07-16 13:38:59
$dictionary["UP_GDPR_3_PC"]["fields"]["up_gdpr_4_pp_up_gdpr_3_pc"] = array (
  'name' => 'up_gdpr_4_pp_up_gdpr_3_pc',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_up_gdpr_3_pc',
  'source' => 'non-db',
  'module' => 'UP_GDPR_4_PP',
  'bean_name' => 'UP_GDPR_4_PP',
  'vname' => 'LBL_UP_GDPR_4_PP_UP_GDPR_3_PC_FROM_UP_GDPR_4_PP_TITLE',
  'id_name' => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_4_pp_ida',
);
$dictionary["UP_GDPR_3_PC"]["fields"]["up_gdpr_4_pp_up_gdpr_3_pc_name"] = array (
  'name' => 'up_gdpr_4_pp_up_gdpr_3_pc_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_4_PP_UP_GDPR_3_PC_FROM_UP_GDPR_4_PP_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_4_pp_ida',
  'link' => 'up_gdpr_4_pp_up_gdpr_3_pc',
  'table' => 'up_gdpr_4_pp',
  'module' => 'UP_GDPR_4_PP',
  'rname' => 'name',
);
$dictionary["UP_GDPR_3_PC"]["fields"]["up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_4_pp_ida"] = array (
  'name' => 'up_gdpr_4_pp_up_gdpr_3_pcup_gdpr_4_pp_ida',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_up_gdpr_3_pc',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_UP_GDPR_4_PP_UP_GDPR_3_PC_FROM_UP_GDPR_3_PC_TITLE',
);
