<?php
// created: 2019-07-16 13:38:59
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_up_gdpr_3_pc"] = array (
  'name' => 'up_gdpr_4_pp_up_gdpr_3_pc',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_up_gdpr_3_pc',
  'source' => 'non-db',
  'module' => 'UP_GDPR_3_PC',
  'bean_name' => 'UP_GDPR_3_PC',
  'side' => 'right',
  'vname' => 'LBL_UP_GDPR_4_PP_UP_GDPR_3_PC_FROM_UP_GDPR_3_PC_TITLE',
);
