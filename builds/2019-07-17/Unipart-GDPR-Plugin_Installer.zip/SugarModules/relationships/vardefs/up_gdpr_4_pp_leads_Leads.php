<?php
// created: 2019-07-16 13:38:59
$dictionary["Lead"]["fields"]["up_gdpr_4_pp_leads"] = array (
  'name' => 'up_gdpr_4_pp_leads',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_leads',
  'source' => 'non-db',
  'module' => 'UP_GDPR_4_PP',
  'bean_name' => 'UP_GDPR_4_PP',
  'vname' => 'LBL_UP_GDPR_4_PP_LEADS_FROM_UP_GDPR_4_PP_TITLE',
  'id_name' => 'up_gdpr_4_pp_leadsup_gdpr_4_pp_ida',
);
$dictionary["Lead"]["fields"]["up_gdpr_4_pp_leads_name"] = array (
  'name' => 'up_gdpr_4_pp_leads_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_4_PP_LEADS_FROM_UP_GDPR_4_PP_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_4_pp_leadsup_gdpr_4_pp_ida',
  'link' => 'up_gdpr_4_pp_leads',
  'table' => 'up_gdpr_4_pp',
  'module' => 'UP_GDPR_4_PP',
  'rname' => 'name',
);
$dictionary["Lead"]["fields"]["up_gdpr_4_pp_leadsup_gdpr_4_pp_ida"] = array (
  'name' => 'up_gdpr_4_pp_leadsup_gdpr_4_pp_ida',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_leads',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_4_PP_LEADS_FROM_UP_GDPR_4_PP_TITLE',
);
