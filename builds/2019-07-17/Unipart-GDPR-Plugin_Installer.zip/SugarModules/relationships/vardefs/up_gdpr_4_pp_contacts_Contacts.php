<?php
// created: 2019-07-16 13:38:59
$dictionary["Contact"]["fields"]["up_gdpr_4_pp_contacts"] = array (
  'name' => 'up_gdpr_4_pp_contacts',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_contacts',
  'source' => 'non-db',
  'module' => 'UP_GDPR_4_PP',
  'bean_name' => 'UP_GDPR_4_PP',
  'vname' => 'LBL_UP_GDPR_4_PP_CONTACTS_FROM_UP_GDPR_4_PP_TITLE',
  'id_name' => 'up_gdpr_4_pp_contactsup_gdpr_4_pp_ida',
);
$dictionary["Contact"]["fields"]["up_gdpr_4_pp_contacts_name"] = array (
  'name' => 'up_gdpr_4_pp_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_4_PP_CONTACTS_FROM_UP_GDPR_4_PP_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_4_pp_contactsup_gdpr_4_pp_ida',
  'link' => 'up_gdpr_4_pp_contacts',
  'table' => 'up_gdpr_4_pp',
  'module' => 'UP_GDPR_4_PP',
  'rname' => 'name',
);
$dictionary["Contact"]["fields"]["up_gdpr_4_pp_contactsup_gdpr_4_pp_ida"] = array (
  'name' => 'up_gdpr_4_pp_contactsup_gdpr_4_pp_ida',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_4_PP_CONTACTS_FROM_UP_GDPR_4_PP_TITLE',
);
