<?php
// created: 2019-07-16 13:38:59
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_accounts"] = array (
  'name' => 'up_gdpr_4_pp_accounts',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_UP_GDPR_4_PP_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'up_gdpr_4_pp_accountsaccounts_idb',
);
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_accounts_name"] = array (
  'name' => 'up_gdpr_4_pp_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_4_PP_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_4_pp_accountsaccounts_idb',
  'link' => 'up_gdpr_4_pp_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_accountsaccounts_idb"] = array (
  'name' => 'up_gdpr_4_pp_accountsaccounts_idb',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_4_PP_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
