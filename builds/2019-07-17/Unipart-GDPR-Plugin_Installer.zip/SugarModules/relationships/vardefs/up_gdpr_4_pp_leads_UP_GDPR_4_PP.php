<?php
// created: 2019-07-16 13:38:59
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_leads"] = array (
  'name' => 'up_gdpr_4_pp_leads',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_UP_GDPR_4_PP_LEADS_FROM_LEADS_TITLE',
  'id_name' => 'up_gdpr_4_pp_leadsleads_idb',
);
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_leads_name"] = array (
  'name' => 'up_gdpr_4_pp_leads_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_4_PP_LEADS_FROM_LEADS_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_4_pp_leadsleads_idb',
  'link' => 'up_gdpr_4_pp_leads',
  'table' => 'leads',
  'module' => 'Leads',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_leadsleads_idb"] = array (
  'name' => 'up_gdpr_4_pp_leadsleads_idb',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_leads',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_4_PP_LEADS_FROM_LEADS_TITLE',
);
