<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2018 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

$app_list_strings['moduleList']['UP_GDPR_4_PP'] = 'GDPR - 4 - Privacy Preferences';
$app_list_strings['moduleList']['UP_GDPR_2_TFR'] = 'GDPR - 2 - Text Field Reviews';
$app_list_strings['moduleList']['UP_GDPR_5_LIR'] = 'GDPR - 5 - Lapsed Interest Reviews';
$app_list_strings['moduleList']['UP_GDPR_1_TFT'] = 'GDPR - 1 - Text Field Types';
$app_list_strings['moduleList']['UP_GDPR_3_PC'] = 'GDPR - 3 - Privacy Campaigns';
$app_list_strings['gdpr_2_tfr_status_list']['pending'] = 'Pending';
$app_list_strings['gdpr_2_tfr_status_list']['approved'] = 'Approved';
$app_list_strings['gdpr_2_tfr_status_list']['rejected'] = 'Rejected';
$app_list_strings['gdpr_3_pc_color_list']['info'] = 'Info';
$app_list_strings['gdpr_3_pc_color_list']['success'] = 'Success';
$app_list_strings['gdpr_3_pc_color_list']['secondary'] = 'Secondary';
$app_list_strings['gdpr_3_pc_color_list']['warning'] = 'Warning';
$app_list_strings['gdpr_3_pc_color_list']['danger'] = 'Danger';
$app_list_strings['gdpr_4_pp_target_type_list']['Account'] = 'Accounts';
$app_list_strings['gdpr_4_pp_target_type_list']['Contact'] = 'Contacts';
$app_list_strings['gdpr_4_pp_target_type_list']['Lead'] = 'Leads';
$app_list_strings['gdpr_5_lir_status_list']['legitimate'] = 'Legitimate';
$app_list_strings['gdpr_5_lir_status_list']['nearly_lapsed'] = 'Nearly Lapsed';
$app_list_strings['gdpr_5_lir_status_list']['lapsed'] = 'Lapsed';
$app_list_strings['gdpr_1_tft_bean_type_list']['Home'] = 'Home';
/**
 * Created by PhpStorm.
 * User: Riccardo De Leo
 */
global $moduleList;
global $beanList;

/**
 * Note: It is not possible to just flip the $beanList
 */
$app_list_strings['gdpr_1_tft_bean_type_list'] = array_reduce(
    $moduleList,
    function ($carry, $moduleName) use ($beanList) {
        if (empty($moduleName) || !isset($beanList[$moduleName]) || empty($beanList[$moduleName])) {
            return $carry;
        }

        $carry[$beanList[$moduleName]] = $moduleName;
        return $carry;
    },
    []
);

$app_strings["LBL_GDPR_PP_PAGE_HEADER_META_DESCRIPTION"] = "Unipart - SuiteCRM GDPR Plugin";
$app_strings["LBL_GDPR_PP_PAGE_HEADER_META_AUTHOR"] = "Riccardo De Leo";
$app_strings["LBL_GDPR_PP_PAGE_HEADER_META_TITLE"] = "Unipart GDPR";
$app_strings["LBL_GDPR_PP_PAGE_BODY_TITLE"] = "Privacy Preferences Page";
$app_strings["LBL_GDPR_PP_PAGE_BODY_DESCRIPTION"] = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac ipsum neque. In hac habitasse platea dictumst. Etiam a mauris vitae metus luctus consequat. Sed lobortis faucibus ligula vitae pretium. Donec vitae velit est. Praesent nec dictum lectus, sodales cursus lectus. Praesent sem ex, feugiat eget mauris dictum, elementum convallis purus. Suspendisse potenti. Pellentesque et pharetra metus, et pulvinar nunc. Duis commodo venenatis dui ultrices ullamcorper. Nullam blandit aliquam enim, id pellentesque felis fringilla et.";
$app_strings["LBL_GDPR_PP_PAGE_BODY_FORM_SUBMIT_BUTTON"] = "Send GDPR Preferences &raquo;";
$app_strings["LBL_GDPR_PP_PAGE_FOOTER_TEXT"] = "© 2019 Unipart Digital Team. All rights reserved.";
$app_strings["LBL_GDPR_PP_PAGE_ERROR_EMPTY_UUID"] = "Invalid privacy preferences id, please contact our operation support.";
$app_strings["LBL_GDPR_PP_PAGE_ERROR_UNEXPECTED"] = "Unexpected internal server error, please contact our operation support.";
$app_strings["LBL_GDPR_PP_PAGE_ERROR_INVALID_UUID"] = "Invalid privacy preference unique id, please contact our operation support.";
$app_strings["LBL_GDPR_PP_PAGE_ERROR_SECURITY_MISMATCH"] = "Update privacy preferences error: security id does not match, please contact our operation support.";
$app_strings["LBL_GDPR_PP_PAGE_SUCCESS_UPDATE"] = "Privacy Preferences successfully updated.";