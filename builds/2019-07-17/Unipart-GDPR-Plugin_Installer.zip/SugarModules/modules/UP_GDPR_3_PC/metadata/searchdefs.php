<?php
$module_name = 'UP_GDPR_3_PC';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'color' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_COLOR',
        'width' => '10%',
        'name' => 'color',
      ),
      'show_modal' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SHOW_MODAL',
        'width' => '10%',
        'name' => 'show_modal',
      ),
      'enabled' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_ENABLED',
        'width' => '10%',
        'name' => 'enabled',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'color' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_COLOR',
        'width' => '10%',
        'name' => 'color',
      ),
      'show_modal' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SHOW_MODAL',
        'width' => '10%',
        'name' => 'show_modal',
      ),
      'enabled' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_ENABLED',
        'width' => '10%',
        'name' => 'enabled',
      ),
      'created_by' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_CREATED',
        'width' => '10%',
        'default' => true,
        'name' => 'created_by',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'modified_user_id' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'modified_user_id',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
