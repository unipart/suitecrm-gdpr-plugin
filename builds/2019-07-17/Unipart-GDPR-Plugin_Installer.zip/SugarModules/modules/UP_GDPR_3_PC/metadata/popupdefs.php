<?php
$popupMeta = array (
    'moduleMain' => 'UP_GDPR_3_PC',
    'varName' => 'UP_GDPR_3_PC',
    'orderBy' => 'up_gdpr_3_pc.name',
    'whereClauses' => array (
  'name' => 'up_gdpr_3_pc.name',
  'color' => 'up_gdpr_3_pc.color',
  'show_modal' => 'up_gdpr_3_pc.show_modal',
  'enabled' => 'up_gdpr_3_pc.enabled',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'color',
  5 => 'show_modal',
  6 => 'enabled',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'color' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_COLOR',
    'width' => '10%',
    'name' => 'color',
  ),
  'show_modal' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_SHOW_MODAL',
    'width' => '10%',
    'name' => 'show_modal',
  ),
  'enabled' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_ENABLED',
    'width' => '10%',
    'name' => 'enabled',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '40%',
    'default' => true,
    'name' => 'name',
  ),
  'COLOR' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_COLOR',
    'width' => '20%',
    'name' => 'color',
  ),
  'SHOW_MODAL' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_SHOW_MODAL',
    'width' => '10%',
    'name' => 'show_modal',
  ),
  'ENABLED' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENABLED',
    'width' => '10%',
    'name' => 'enabled',
  ),
),
);
