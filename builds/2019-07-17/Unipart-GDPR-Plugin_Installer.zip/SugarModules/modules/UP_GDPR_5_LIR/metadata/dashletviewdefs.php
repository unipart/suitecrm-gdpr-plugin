<?php
$dashletData['UP_GDPR_5_LIRDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'status' => 
  array (
    'default' => '',
  ),
  'days_before_lapse' => 
  array (
    'default' => '',
  ),
  'lapse_date' => 
  array (
    'default' => '',
  ),
);
$dashletData['UP_GDPR_5_LIRDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'status' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'width' => '10%',
    'name' => 'status',
  ),
  'days_before_lapse' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DAYS_BEFORE_LAPSE',
    'width' => '10%',
    'default' => true,
    'name' => 'days_before_lapse',
  ),
  'lapse_date' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LAPSE_DATE',
    'width' => '10%',
    'default' => true,
    'name' => 'lapse_date',
  ),
  'created_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
    'name' => 'created_by_name',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'modified_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
    'name' => 'modified_by_name',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
);
