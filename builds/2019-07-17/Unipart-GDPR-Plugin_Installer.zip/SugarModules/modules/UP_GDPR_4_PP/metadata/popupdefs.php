<?php
$popupMeta = array (
    'moduleMain' => 'UP_GDPR_4_PP',
    'varName' => 'UP_GDPR_4_PP',
    'orderBy' => 'up_gdpr_4_pp.name',
    'whereClauses' => array (
  'name' => 'up_gdpr_4_pp.name',
  'target_type' => 'up_gdpr_4_pp.target_type',
  'target_id' => 'up_gdpr_4_pp.target_id',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'target_type',
  5 => 'target_id',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'target_type' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TARGET_TYPE',
    'width' => '10%',
    'name' => 'target_type',
  ),
  'target_id' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TARGET_ID',
    'width' => '10%',
    'name' => 'target_id',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'TARGET_TYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TARGET_TYPE',
    'width' => '10%',
    'default' => true,
    'name' => 'target_type',
  ),
  'TARGET_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TARGET_ID',
    'width' => '10%',
    'default' => true,
    'name' => 'target_id',
  ),
),
);
