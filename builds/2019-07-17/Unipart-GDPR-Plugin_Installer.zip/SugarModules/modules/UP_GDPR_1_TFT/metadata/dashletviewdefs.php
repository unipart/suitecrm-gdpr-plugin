<?php
$dashletData['UP_GDPR_1_TFTDashlet']['searchFields'] = array (
  'bean_type' => 
  array (
    'default' => '',
  ),
  'field_name' => 
  array (
    'default' => '',
  ),
  'enabled' => 
  array (
    'default' => '',
  ),
);
$dashletData['UP_GDPR_1_TFTDashlet']['columns'] = array (
  'bean_type' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_BEAN_TYPE',
    'width' => '40%',
    'default' => true,
    'name' => 'bean_type',
  ),
  'field_name' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIELD_NAME',
    'width' => '30%',
    'default' => true,
    'name' => 'field_name',
  ),
  'enabled' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENABLED',
    'width' => '30%',
    'name' => 'enabled',
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'modified_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
    'name' => 'modified_by_name',
  ),
);
