<?php
/**
 * Created by PhpStorm.
 * User: Riccardo De Leo
 */
$mod_strings['LBL_CALCULATEGDPRLAPSEDINTEREST'] = 'Calculate GDPR Lapsed Interest';