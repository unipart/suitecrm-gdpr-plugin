<?php
$popupMeta = array (
    'moduleMain' => 'UP_GDPR_5_LIR',
    'varName' => 'UP_GDPR_5_LIR',
    'orderBy' => 'up_gdpr_5_lir.name',
    'whereClauses' => array (
  'name' => 'up_gdpr_5_lir.name',
  'days_before_lapse' => 'up_gdpr_5_lir.days_before_lapse',
  'status' => 'up_gdpr_5_lir.status',
  'lapse_date' => 'up_gdpr_5_lir.lapse_date',
),
    'searchInputs' => array (
  1 => 'name',
  3 => 'status',
  4 => 'days_before_lapse',
  5 => 'lapse_date',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'status' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'width' => '10%',
    'name' => 'status',
  ),
  'days_before_lapse' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DAYS_BEFORE_LAPSE',
    'width' => '10%',
    'name' => 'days_before_lapse',
  ),
  'lapse_date' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LAPSE_DATE',
    'width' => '10%',
    'name' => 'lapse_date',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'STATUS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'width' => '10%',
    'name' => 'status',
  ),
  'DAYS_BEFORE_LAPSE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DAYS_BEFORE_LAPSE',
    'width' => '10%',
    'default' => true,
    'name' => 'days_before_lapse',
  ),
  'LAPSE_DATE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LAPSE_DATE',
    'width' => '10%',
    'default' => true,
    'name' => 'lapse_date',
  ),
),
);
