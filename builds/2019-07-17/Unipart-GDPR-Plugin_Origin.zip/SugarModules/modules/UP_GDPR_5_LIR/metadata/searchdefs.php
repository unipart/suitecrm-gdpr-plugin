<?php
$module_name = 'UP_GDPR_5_LIR';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'status' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_STATUS',
        'width' => '10%',
        'name' => 'status',
      ),
      'days_before_lapse' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_DAYS_BEFORE_LAPSE',
        'width' => '10%',
        'default' => true,
        'name' => 'days_before_lapse',
      ),
      'lapse_date' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LAPSE_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'lapse_date',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'status' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_STATUS',
        'width' => '10%',
        'name' => 'status',
      ),
      'days_before_lapse' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_DAYS_BEFORE_LAPSE',
        'width' => '10%',
        'default' => true,
        'name' => 'days_before_lapse',
      ),
      'lapse_date' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LAPSE_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'lapse_date',
      ),
      'target_id' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_TARGET_ID',
        'width' => '10%',
        'default' => true,
        'name' => 'target_id',
      ),
      'created_by' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_CREATED',
        'width' => '10%',
        'default' => true,
        'name' => 'created_by',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'modified_user_id' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'modified_user_id',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
