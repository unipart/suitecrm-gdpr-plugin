<?php
$module_name = 'UP_GDPR_1_TFT';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'bean_type',
            'studio' => 'visible',
            'label' => 'LBL_BEAN_TYPE',
          ),
          1 => 
          array (
            'name' => 'enabled',
            'label' => 'LBL_ENABLED',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'field_name',
            'label' => 'LBL_FIELD_NAME',
          ),
        ),
        2 => 
        array (
          0 => 'description',
        ),
      ),
    ),
  ),
);
?>
