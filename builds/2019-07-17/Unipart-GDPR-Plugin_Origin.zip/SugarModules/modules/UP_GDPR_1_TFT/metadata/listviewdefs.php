<?php
$module_name = 'UP_GDPR_1_TFT';
$listViewDefs [$module_name] = 
array (
  'BEAN_TYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_BEAN_TYPE',
    'width' => '40%',
    'default' => true,
  ),
  'FIELD_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIELD_NAME',
    'width' => '30%',
    'default' => true,
  ),
  'ENABLED' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENABLED',
    'width' => '30%',
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
);
?>
