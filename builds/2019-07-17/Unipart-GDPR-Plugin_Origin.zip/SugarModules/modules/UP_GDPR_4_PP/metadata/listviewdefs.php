<?php
$module_name = 'UP_GDPR_4_PP';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'TARGET_TYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TARGET_TYPE',
    'width' => '10%',
    'default' => true,
  ),
  'TARGET_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TARGET_ID',
    'width' => '10%',
    'default' => true,
  ),
  'UUID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UUID',
    'width' => '10%',
    'default' => false,
  ),
  'URL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_URL',
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
);
?>
