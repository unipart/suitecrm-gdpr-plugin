<?php
$dashletData['UP_GDPR_4_PPDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'target_type' => 
  array (
    'default' => '',
  ),
  'target_id' => 
  array (
    'default' => '',
  ),
);
$dashletData['UP_GDPR_4_PPDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'target_type' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TARGET_TYPE',
    'width' => '10%',
    'default' => true,
  ),
  'target_id' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TARGET_ID',
    'width' => '10%',
    'default' => true,
  ),
  'uuid' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UUID',
    'width' => '10%',
    'default' => false,
  ),
  'url' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_URL',
    'width' => '10%',
    'default' => false,
  ),
  'created_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'modified_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
);
