<?php
$popupMeta = array (
    'moduleMain' => 'UP_GDPR_2_TFR',
    'varName' => 'UP_GDPR_2_TFR',
    'orderBy' => 'up_gdpr_2_tfr.name',
    'whereClauses' => array (
  'name' => 'up_gdpr_2_tfr.name',
  'status' => 'up_gdpr_2_tfr.status',
  'up_gdpr_2_tfr_users_name' => 'up_gdpr_2_tfr.up_gdpr_2_tfr_users_name',
  'up_gdpr_2_tfr_up_gdpr_1_tft_name' => 'up_gdpr_2_tfr.up_gdpr_2_tfr_up_gdpr_1_tft_name',
),
    'searchInputs' => array (
  1 => 'name',
  3 => 'status',
  4 => 'up_gdpr_2_tfr_users_name',
  5 => 'up_gdpr_2_tfr_up_gdpr_1_tft_name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'status' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'width' => '10%',
    'name' => 'status',
  ),
  'up_gdpr_2_tfr_users_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
    'id' => 'UP_GDPR_2_TFR_USERSUSERS_IDA',
    'width' => '10%',
    'name' => 'up_gdpr_2_tfr_users_name',
  ),
  'up_gdpr_2_tfr_up_gdpr_1_tft_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_UP_GDPR_2_TFR_UP_GDPR_1_TFT_FROM_UP_GDPR_1_TFT_TITLE',
    'id' => 'UP_GDPR_2_TFR_UP_GDPR_1_TFTUP_GDPR_1_TFT_IDA',
    'width' => '10%',
    'name' => 'up_gdpr_2_tfr_up_gdpr_1_tft_name',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '40%',
    'default' => true,
    'name' => 'name',
  ),
  'STATUS' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'default' => true,
    'label' => 'LBL_STATUS',
    'width' => '30%',
    'name' => 'status',
  ),
  'UP_GDPR_2_TFR_USERS_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
    'id' => 'UP_GDPR_2_TFR_USERSUSERS_IDA',
    'width' => '30%',
    'default' => true,
    'name' => 'up_gdpr_2_tfr_users_name',
  ),
),
);
