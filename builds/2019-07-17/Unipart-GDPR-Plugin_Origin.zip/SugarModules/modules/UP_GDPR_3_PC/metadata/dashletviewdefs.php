<?php
$dashletData['UP_GDPR_3_PCDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'color' => 
  array (
    'default' => '',
  ),
  'show_modal' => 
  array (
    'default' => '',
  ),
  'enabled' => 
  array (
    'default' => '',
  ),
);
$dashletData['UP_GDPR_3_PCDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'color' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_COLOR',
    'width' => '20%',
    'name' => 'color',
  ),
  'show_modal' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_SHOW_MODAL',
    'width' => '10%',
    'name' => 'show_modal',
  ),
  'enabled' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENABLED',
    'width' => '10%',
    'name' => 'enabled',
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'modified_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
    'name' => 'modified_by_name',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
);
