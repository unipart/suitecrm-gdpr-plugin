<?php
// created: 2019-07-16 13:38:59
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_contacts"] = array (
  'name' => 'up_gdpr_4_pp_contacts',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_UP_GDPR_4_PP_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'up_gdpr_4_pp_contactscontacts_idb',
);
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_contacts_name"] = array (
  'name' => 'up_gdpr_4_pp_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_4_PP_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_4_pp_contactscontacts_idb',
  'link' => 'up_gdpr_4_pp_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["UP_GDPR_4_PP"]["fields"]["up_gdpr_4_pp_contactscontacts_idb"] = array (
  'name' => 'up_gdpr_4_pp_contactscontacts_idb',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_4_PP_CONTACTS_FROM_CONTACTS_TITLE',
);
