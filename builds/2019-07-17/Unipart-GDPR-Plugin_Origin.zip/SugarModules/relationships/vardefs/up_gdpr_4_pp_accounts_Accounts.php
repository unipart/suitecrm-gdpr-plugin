<?php
// created: 2019-07-16 13:38:59
$dictionary["Account"]["fields"]["up_gdpr_4_pp_accounts"] = array (
  'name' => 'up_gdpr_4_pp_accounts',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_accounts',
  'source' => 'non-db',
  'module' => 'UP_GDPR_4_PP',
  'bean_name' => 'UP_GDPR_4_PP',
  'vname' => 'LBL_UP_GDPR_4_PP_ACCOUNTS_FROM_UP_GDPR_4_PP_TITLE',
  'id_name' => 'up_gdpr_4_pp_accountsup_gdpr_4_pp_ida',
);
$dictionary["Account"]["fields"]["up_gdpr_4_pp_accounts_name"] = array (
  'name' => 'up_gdpr_4_pp_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_4_PP_ACCOUNTS_FROM_UP_GDPR_4_PP_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_4_pp_accountsup_gdpr_4_pp_ida',
  'link' => 'up_gdpr_4_pp_accounts',
  'table' => 'up_gdpr_4_pp',
  'module' => 'UP_GDPR_4_PP',
  'rname' => 'name',
);
$dictionary["Account"]["fields"]["up_gdpr_4_pp_accountsup_gdpr_4_pp_ida"] = array (
  'name' => 'up_gdpr_4_pp_accountsup_gdpr_4_pp_ida',
  'type' => 'link',
  'relationship' => 'up_gdpr_4_pp_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_4_PP_ACCOUNTS_FROM_UP_GDPR_4_PP_TITLE',
);
