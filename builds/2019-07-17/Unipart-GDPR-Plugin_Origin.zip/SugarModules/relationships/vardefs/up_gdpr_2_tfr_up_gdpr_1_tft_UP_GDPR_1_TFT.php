<?php
// created: 2019-07-16 13:39:00
$dictionary["UP_GDPR_1_TFT"]["fields"]["up_gdpr_2_tfr_up_gdpr_1_tft"] = array (
  'name' => 'up_gdpr_2_tfr_up_gdpr_1_tft',
  'type' => 'link',
  'relationship' => 'up_gdpr_2_tfr_up_gdpr_1_tft',
  'source' => 'non-db',
  'module' => 'UP_GDPR_2_TFR',
  'bean_name' => 'UP_GDPR_2_TFR',
  'side' => 'right',
  'vname' => 'LBL_UP_GDPR_2_TFR_UP_GDPR_1_TFT_FROM_UP_GDPR_2_TFR_TITLE',
);
