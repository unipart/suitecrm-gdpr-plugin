<?php
// created: 2019-07-16 13:39:00
$dictionary["User"]["fields"]["up_gdpr_2_tfr_users"] = array (
  'name' => 'up_gdpr_2_tfr_users',
  'type' => 'link',
  'relationship' => 'up_gdpr_2_tfr_users',
  'source' => 'non-db',
  'module' => 'UP_GDPR_2_TFR',
  'bean_name' => 'UP_GDPR_2_TFR',
  'side' => 'right',
  'vname' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_UP_GDPR_2_TFR_TITLE',
);
