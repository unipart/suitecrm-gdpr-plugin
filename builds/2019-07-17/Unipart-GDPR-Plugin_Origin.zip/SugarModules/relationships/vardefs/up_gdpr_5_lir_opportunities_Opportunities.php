<?php
// created: 2019-07-16 13:39:00
$dictionary["Opportunity"]["fields"]["up_gdpr_5_lir_opportunities"] = array (
  'name' => 'up_gdpr_5_lir_opportunities',
  'type' => 'link',
  'relationship' => 'up_gdpr_5_lir_opportunities',
  'source' => 'non-db',
  'module' => 'UP_GDPR_5_LIR',
  'bean_name' => 'UP_GDPR_5_LIR',
  'vname' => 'LBL_UP_GDPR_5_LIR_OPPORTUNITIES_FROM_UP_GDPR_5_LIR_TITLE',
  'id_name' => 'up_gdpr_5_lir_opportunitiesup_gdpr_5_lir_ida',
);
$dictionary["Opportunity"]["fields"]["up_gdpr_5_lir_opportunities_name"] = array (
  'name' => 'up_gdpr_5_lir_opportunities_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_5_LIR_OPPORTUNITIES_FROM_UP_GDPR_5_LIR_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_5_lir_opportunitiesup_gdpr_5_lir_ida',
  'link' => 'up_gdpr_5_lir_opportunities',
  'table' => 'up_gdpr_5_lir',
  'module' => 'UP_GDPR_5_LIR',
  'rname' => 'name',
);
$dictionary["Opportunity"]["fields"]["up_gdpr_5_lir_opportunitiesup_gdpr_5_lir_ida"] = array (
  'name' => 'up_gdpr_5_lir_opportunitiesup_gdpr_5_lir_ida',
  'type' => 'link',
  'relationship' => 'up_gdpr_5_lir_opportunities',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_UP_GDPR_5_LIR_OPPORTUNITIES_FROM_UP_GDPR_5_LIR_TITLE',
);
