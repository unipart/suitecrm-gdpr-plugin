<?php
// created: 2019-07-16 13:39:00
$dictionary["UP_GDPR_2_TFR"]["fields"]["up_gdpr_2_tfr_users"] = array (
  'name' => 'up_gdpr_2_tfr_users',
  'type' => 'link',
  'relationship' => 'up_gdpr_2_tfr_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
  'id_name' => 'up_gdpr_2_tfr_usersusers_ida',
);
$dictionary["UP_GDPR_2_TFR"]["fields"]["up_gdpr_2_tfr_users_name"] = array (
  'name' => 'up_gdpr_2_tfr_users_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
  'save' => true,
  'id_name' => 'up_gdpr_2_tfr_usersusers_ida',
  'link' => 'up_gdpr_2_tfr_users',
  'table' => 'users',
  'module' => 'Users',
  'rname' => 'name',
);
$dictionary["UP_GDPR_2_TFR"]["fields"]["up_gdpr_2_tfr_usersusers_ida"] = array (
  'name' => 'up_gdpr_2_tfr_usersusers_ida',
  'type' => 'link',
  'relationship' => 'up_gdpr_2_tfr_users',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_UP_GDPR_2_TFR_TITLE',
);
