<?php
 // created: 2019-07-16 13:39:00
$layout_defs["UP_GDPR_1_TFT"]["subpanel_setup"]['up_gdpr_2_tfr_up_gdpr_1_tft'] = array (
  'order' => 100,
  'module' => 'UP_GDPR_2_TFR',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_UP_GDPR_2_TFR_UP_GDPR_1_TFT_FROM_UP_GDPR_2_TFR_TITLE',
  'get_subpanel_data' => 'up_gdpr_2_tfr_up_gdpr_1_tft',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
