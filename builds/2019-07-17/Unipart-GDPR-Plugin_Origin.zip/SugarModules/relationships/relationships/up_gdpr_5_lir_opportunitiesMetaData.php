<?php
// created: 2019-07-16 13:39:00
$dictionary["up_gdpr_5_lir_opportunities"] = array (
  'true_relationship_type' => 'one-to-one',
  'relationships' => 
  array (
    'up_gdpr_5_lir_opportunities' => 
    array (
      'lhs_module' => 'UP_GDPR_5_LIR',
      'lhs_table' => 'up_gdpr_5_lir',
      'lhs_key' => 'id',
      'rhs_module' => 'Opportunities',
      'rhs_table' => 'opportunities',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'up_gdpr_5_lir_opportunities_c',
      'join_key_lhs' => 'up_gdpr_5_lir_opportunitiesup_gdpr_5_lir_ida',
      'join_key_rhs' => 'up_gdpr_5_lir_opportunitiesopportunities_idb',
    ),
  ),
  'table' => 'up_gdpr_5_lir_opportunities_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'up_gdpr_5_lir_opportunitiesup_gdpr_5_lir_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'up_gdpr_5_lir_opportunitiesopportunities_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'up_gdpr_5_lir_opportunitiesspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'up_gdpr_5_lir_opportunities_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'up_gdpr_5_lir_opportunitiesup_gdpr_5_lir_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'up_gdpr_5_lir_opportunities_idb2',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'up_gdpr_5_lir_opportunitiesopportunities_idb',
      ),
    ),
  ),
);