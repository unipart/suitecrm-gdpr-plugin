<?php
$module_name = 'UP_GDPR_1_TFT';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'bean_type' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_BEAN_TYPE',
        'width' => '10%',
        'default' => true,
        'name' => 'bean_type',
      ),
      'field_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_FIELD_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'field_name',
      ),
      'enabled' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_ENABLED',
        'width' => '10%',
        'name' => 'enabled',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'bean_type' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_BEAN_TYPE',
        'width' => '10%',
        'default' => true,
        'name' => 'bean_type',
      ),
      'field_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_FIELD_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'field_name',
      ),
      'enabled' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_ENABLED',
        'width' => '10%',
        'name' => 'enabled',
      ),
      'created_by' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_CREATED',
        'width' => '10%',
        'default' => true,
        'name' => 'created_by',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'modified_user_id' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'modified_user_id',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
