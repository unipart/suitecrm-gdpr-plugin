<?php
$popupMeta = array (
    'moduleMain' => 'UP_GDPR_1_TFT',
    'varName' => 'UP_GDPR_1_TFT',
    'orderBy' => 'up_gdpr_1_tft.name',
    'whereClauses' => array (
  'bean_type' => 'up_gdpr_1_tft.bean_type',
  'field_name' => 'up_gdpr_1_tft.field_name',
  'enabled' => 'up_gdpr_1_tft.enabled',
),
    'searchInputs' => array (
  4 => 'bean_type',
  5 => 'field_name',
  6 => 'enabled',
),
    'searchdefs' => array (
  'bean_type' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BEAN_TYPE',
    'width' => '10%',
    'name' => 'bean_type',
  ),
  'field_name' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIELD_NAME',
    'width' => '10%',
    'name' => 'field_name',
  ),
  'enabled' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_ENABLED',
    'width' => '10%',
    'name' => 'enabled',
  ),
),
    'listviewdefs' => array (
  'BEAN_TYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_BEAN_TYPE',
    'width' => '40%',
    'default' => true,
    'name' => 'bean_type',
  ),
  'FIELD_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIELD_NAME',
    'width' => '30%',
    'default' => true,
    'name' => 'field_name',
  ),
  'ENABLED' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ENABLED',
    'width' => '30%',
    'name' => 'enabled',
  ),
),
);
