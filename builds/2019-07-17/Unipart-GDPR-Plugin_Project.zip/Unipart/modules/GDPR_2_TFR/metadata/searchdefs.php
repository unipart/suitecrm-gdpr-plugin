<?php
$module_name = 'UP_GDPR_2_TFR';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'status' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'default' => true,
        'label' => 'LBL_STATUS',
        'width' => '10%',
        'name' => 'status',
      ),
      'up_gdpr_2_tfr_users_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
        'id' => 'UP_GDPR_2_TFR_USERSUSERS_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'up_gdpr_2_tfr_users_name',
      ),
      'up_gdpr_2_tfr_up_gdpr_1_tft_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_UP_GDPR_2_TFR_UP_GDPR_1_TFT_FROM_UP_GDPR_1_TFT_TITLE',
        'id' => 'UP_GDPR_2_TFR_UP_GDPR_1_TFTUP_GDPR_1_TFT_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'up_gdpr_2_tfr_up_gdpr_1_tft_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'status' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'default' => true,
        'label' => 'LBL_STATUS',
        'width' => '10%',
        'name' => 'status',
      ),
      'up_gdpr_2_tfr_users_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'UP_GDPR_2_TFR_USERSUSERS_IDA',
        'name' => 'up_gdpr_2_tfr_users_name',
      ),
      'target_id' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_TARGET_ID',
        'width' => '10%',
        'default' => true,
        'name' => 'target_id',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
      'modified_user_id' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'modified_user_id',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
