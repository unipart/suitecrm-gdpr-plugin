<?php
$dashletData['UP_GDPR_2_TFRDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'status' => 
  array (
    'default' => '',
  ),
  'up_gdpr_2_tfr_users_name' => 
  array (
    'default' => '',
  ),
  'up_gdpr_2_tfr_up_gdpr_1_tft_name' => 
  array (
    'default' => '',
  ),
);
$dashletData['UP_GDPR_2_TFRDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'status' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'default' => true,
    'label' => 'LBL_STATUS',
    'width' => '30%',
    'name' => 'status',
  ),
  'up_gdpr_2_tfr_users_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
    'id' => 'UP_GDPR_2_TFR_USERSUSERS_IDA',
    'width' => '30%',
    'default' => true,
    'name' => 'up_gdpr_2_tfr_users_name',
  ),
  'target_id' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TARGET_ID',
    'width' => '10%',
    'default' => false,
    'name' => 'target_id',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'modified_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
    'name' => 'modified_by_name',
  ),
  'up_gdpr_2_tfr_up_gdpr_1_tft_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_UP_GDPR_2_TFR_UP_GDPR_1_TFT_FROM_UP_GDPR_1_TFT_TITLE',
    'id' => 'UP_GDPR_2_TFR_UP_GDPR_1_TFTUP_GDPR_1_TFT_IDA',
    'width' => '10%',
    'default' => false,
  ),
);
