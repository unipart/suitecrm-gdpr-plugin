<?php
$module_name = 'UP_GDPR_2_TFR';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '40%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'STATUS' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'default' => true,
    'label' => 'LBL_STATUS',
    'width' => '30%',
  ),
  'UP_GDPR_2_TFR_USERS_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_UP_GDPR_2_TFR_USERS_FROM_USERS_TITLE',
    'id' => 'UP_GDPR_2_TFR_USERSUSERS_IDA',
    'width' => '30%',
    'default' => true,
  ),
  'TARGET_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TARGET_ID',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'UP_GDPR_2_TFR_UP_GDPR_1_TFT_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_UP_GDPR_2_TFR_UP_GDPR_1_TFT_FROM_UP_GDPR_1_TFT_TITLE',
    'id' => 'UP_GDPR_2_TFR_UP_GDPR_1_TFTUP_GDPR_1_TFT_IDA',
    'width' => '10%',
    'default' => false,
  ),
);
?>
