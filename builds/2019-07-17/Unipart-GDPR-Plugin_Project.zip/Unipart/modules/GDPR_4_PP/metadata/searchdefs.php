<?php
$module_name = 'UP_GDPR_4_PP';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'target_type' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_TARGET_TYPE',
        'width' => '10%',
        'default' => true,
        'name' => 'target_type',
      ),
      'target_id' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_TARGET_ID',
        'width' => '10%',
        'default' => true,
        'name' => 'target_id',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'target_type' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_TARGET_TYPE',
        'width' => '10%',
        'default' => true,
        'name' => 'target_type',
      ),
      'target_id' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_TARGET_ID',
        'width' => '10%',
        'default' => true,
        'name' => 'target_id',
      ),
      'uuid' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_UUID',
        'width' => '10%',
        'default' => true,
        'name' => 'uuid',
      ),
      'url' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_URL',
        'width' => '10%',
        'default' => true,
        'name' => 'url',
      ),
      'created_by' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_CREATED',
        'width' => '10%',
        'default' => true,
        'name' => 'created_by',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'modified_user_id' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'modified_user_id',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
